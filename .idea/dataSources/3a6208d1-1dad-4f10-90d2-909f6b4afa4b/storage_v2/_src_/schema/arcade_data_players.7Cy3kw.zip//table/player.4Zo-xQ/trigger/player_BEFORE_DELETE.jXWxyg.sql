CREATE TRIGGER player_BEFORE_DELETE
  BEFORE DELETE
  ON player
  FOR EACH ROW
  BEGIN
    INSERT INTO player_old (id, nome, pontos, data)
    VALUES (old.id, old.nome, old.pontos, old.data);
  END;

